<?php
require_once 'config.php';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_id = $_POST['product_id'];
    
    // First remove all existing materials for this product
    $conn->query("DELETE FROM product_materials WHERE product_id = $product_id");
    
    // Then add the selected materials
    if(isset($_POST['materials'])) {
        foreach($_POST['materials'] as $material_id => $quantity) {
            if($quantity > 0) {
                $stmt = $conn->prepare("INSERT INTO product_materials (product_id, material_id, quantity) 
                                      VALUES (?, ?, ?)");
                $stmt->bind_param("iid", $product_id, $material_id, $quantity);
                $stmt->execute();
            }
        }
    }
    
    header("Location: products.php?tab=product-materials&id=$product_id&success=Materials updated successfully");
} else {
    header("Location: products.php");
}
?>