<?php
require_once 'config.php';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $overhead_id = intval($_POST['overhead_id']);
    $allocations = $_POST['allocation_amount'];
    $allocation_bases = $_POST['allocation_base'];
    $allocation_percentages = $_POST['allocation_percentage'];
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // First delete any existing allocations for this overhead
        $conn->query("DELETE FROM overhead_allocations WHERE overhead_id = $overhead_id");
        
        // Insert new allocations
        foreach($allocations as $product_id => $amount) {
            if($amount > 0) {
                $product_id = intval($product_id);
                $amount = floatval($amount);
                $base = $conn->real_escape_string($allocation_bases[$product_id]);
                $percentage = floatval($allocation_percentages[$product_id]);
                
                $stmt = $conn->prepare("INSERT INTO overhead_allocations 
                                      (overhead_id, product_id, allocation_base, allocation_percentage, amount) 
                                      VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("iisdd", $overhead_id, $product_id, $base, $percentage, $amount);
                $stmt->execute();
            }
        }
        
        // Commit transaction
        $conn->commit();
        
        header("Location: overhead.php?success=Overhead allocated successfully");
    } catch (Exception $e) {
        // Rollback on error
        $conn->rollback();
        header("Location: overhead.php?error=Error allocating overhead: " . $e->getMessage());
    }
} else {
    header("Location: overhead.php");
}
?>