<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Overhead Allocation - Production ERP System</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <?php include 'header.php'; ?>
        
        <main>
            <div class="page-header">
                <h2><i class="fas fa-random"></i> Overhead Allocation</h2>
                <div class="breadcrumb">
                    <span>Home</span> / <span class="active">Overhead Allocation</span>
                </div>
            </div>
            
            <div class="card">
                <h3>Allocate Overhead Costs to Products</h3>
                
                <form action="process_overhead_allocation.php" method="POST">
                    <div class="form-group">
                        <label for="overhead_id">Overhead Cost</label>
                        <select class="form-control" id="overhead_id" name="overhead_id" required>
                            <option value="">-- Select Overhead Cost --</option>
                            <?php
                            $query = "SELECT * FROM overhead_costs";
                            $result = $conn->query($query);
                            while($row = $result->fetch_assoc()):
                            ?>
                            <option value="<?php echo $row['id']; ?>">
                                <?php echo $row['name']; ?> (Rp <?php echo number_format($row['amount'], 2); ?>)
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <h4>Allocation to Products</h4>
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Allocation Base</th>
                                    <th>Allocation %</th>
                                    <th>Allocation Amount (Rp)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT * FROM products";
                                $result = $conn->query($query);
                                while($product = $result->fetch_assoc()):
                                ?>
                                <tr>
                                    <td><?php echo $product['name']; ?></td>
                                    <td>
                                        <input type="text" class="form-control" name="allocation_base[<?php echo $product['id']; ?>]" 
                                               placeholder="e.g., labor hours, machine hours" required>
                                    </td>
                                    <td>
                                        <input type="number" step="0.01" class="form-control" name="allocation_percentage[<?php echo $product['id']; ?>]" 
                                               placeholder="%" required>
                                    </td>
                                    <td>
                                        <input type="number" step="0.01" class="form-control" name="allocation_amount[<?php echo $product['id']; ?>]" 
                                               placeholder="Rp" required>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="text-right">
                        <button type="submit" class="btn">Allocate Overhead</button>
                    </div>
                </form>
            </div>
            
            <!-- Previous Allocations -->
            <div class="card">
                <h3>Previous Overhead Allocations</h3>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Overhead Cost</th>
                                <th>Product</th>
                                <th>Allocation Base</th>
                                <th>Allocation %</th>
                                <th>Amount (Rp)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT oa.*, oc.name as overhead_name, p.name as product_name 
                                      FROM overhead_allocations oa
                                      JOIN overhead_costs oc ON oa.overhead_id = oc.id
                                      JOIN products p ON oa.product_id = p.id
                                      ORDER BY oa.created_at DESC";
                            $result = $conn->query($query);
                            
                            if($result && $result->num_rows > 0) {
                                while($row = $result->fetch_assoc()):
                            ?>
                            <tr>
                                <td><?php echo date('d M Y', strtotime($row['created_at'])); ?></td>
                                <td><?php echo $row['overhead_name']; ?></td>
                                <td><?php echo $row['product_name']; ?></td>
                                <td><?php echo $row['allocation_base']; ?></td>
                                <td><?php echo $row['allocation_percentage']; ?>%</td>
                                <td>Rp <?php echo number_format($row['amount'], 2); ?></td>
                            </tr>
                            <?php 
                                endwhile;
                            } else {
                                echo "<tr><td colspan='6'>No overhead allocations found</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    
    <script src="assets/js/script.js"></script>
    <script>
        // Calculate allocation amounts when percentage changes
        document.querySelectorAll('input[name^="allocation_percentage"]').forEach(input => {
            input.addEventListener('change', function() {
                const overheadSelect = document.getElementById('overhead_id');
                const overheadAmount = parseFloat(overheadSelect.options[overheadSelect.selectedIndex].text.match(/Rp ([\d,]+)/)[1].replace(/,/g, ''));
                const percentage = parseFloat(this.value);
                
                if(!isNaN(percentage) && !isNaN(overheadAmount)) {
                    const amountInput = this.closest('tr').querySelector('input[name^="allocation_amount"]');
                    amountInput.value = (overheadAmount * percentage / 100).toFixed(2);
                }
            });
        });
    </script>
</body>
</html>