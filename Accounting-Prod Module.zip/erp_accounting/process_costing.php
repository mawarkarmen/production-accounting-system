<?php
require_once 'config.php';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_id = intval($_POST['product_id']);
    $quantity = intval($_POST['production_quantity']);
    $markup_percentage = floatval($_POST['markup_percentage']);
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // 1. Calculate Direct Materials Cost
        $direct_materials = 0;
        $materials_query = "SELECT m.unit_price, pm.quantity, m.category
                           FROM product_materials pm
                           JOIN materials m ON pm.material_id = m.id
                           WHERE pm.product_id = $product_id";
        $materials_result = $conn->query($materials_query);
        while($row = $materials_result->fetch_assoc()) {
            if($row['category'] == 'direct') {
                $direct_materials += $row['unit_price'] * $row['quantity'];
            }
        }
        
        // 2. Calculate Direct Labor Cost
        $direct_labor = 0;
        $labor_query = "SELECT hourly_rate, hours_per_unit 
                        FROM labor_costs 
                        WHERE category = 'direct'";
        $labor_result = $conn->query($labor_query);
        while($row = $labor_result->fetch_assoc()) {
            $direct_labor += $row['hourly_rate'] * $row['hours_per_unit'];
        }
        
        // 3. Calculate Manufacturing Overhead (allocated overhead + indirect costs)
        $manufacturing_overhead = 0;
        
        // 3a. Allocated overhead costs
        $overhead_query = "SELECT amount 
                          FROM overhead_allocations 
                          WHERE product_id = $product_id";
        $overhead_result = $conn->query($overhead_query);
        while($row = $overhead_result->fetch_assoc()) {
            $manufacturing_overhead += $row['amount'];
        }
        
        // 3b. Indirect materials
        $indirect_materials = 0;
        $materials_result->data_seek(0); // Reset pointer
        while($row = $materials_result->fetch_assoc()) {
            if($row['category'] == 'indirect') {
                $indirect_materials += $row['unit_price'] * $row['quantity'];
            }
        }
        
        // 3c. Indirect labor
        $indirect_labor = 0;
        $indirect_labor_query = "SELECT hourly_rate, hours_per_unit 
                               FROM labor_costs 
                               WHERE category = 'indirect'";
        $indirect_labor_result = $conn->query($indirect_labor_query);
        while($row = $indirect_labor_result->fetch_assoc()) {
            $indirect_labor += $row['hourly_rate'] * $row['hours_per_unit'];
        }
        
        $manufacturing_overhead += $indirect_materials + $indirect_labor;
        
        // 4. Calculate Total Cost and Cost per Unit
        $total_direct_cost = $direct_materials + $direct_labor;
        $total_cost = $total_direct_cost + $manufacturing_overhead;
        $cost_per_unit = $total_cost / $quantity;
        
        // 5. Calculate Selling Price with Markup
        $selling_price = $cost_per_unit * (1 + ($markup_percentage / 100));
        
        // 6. Save to product_costing table
        $stmt = $conn->prepare("INSERT INTO product_costing 
                              (product_id, production_quantity, 
                               direct_materials, direct_labor, 
                               indirect_materials, indirect_labor,
                               allocated_overhead, manufacturing_overhead, 
                               total_direct_cost, total_cost, cost_per_unit, 
                               markup_percentage, selling_price) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iiddddddddddd", 
            $product_id, $quantity,
            $direct_materials, $direct_labor,
            $indirect_materials, $indirect_labor,
            ($manufacturing_overhead - $indirect_materials - $indirect_labor), $manufacturing_overhead,
            $total_direct_cost, $total_cost, $cost_per_unit,
            $markup_percentage, $selling_price);
        $stmt->execute();
        
        // 7. Update finished goods inventory
        $product_name = $conn->query("SELECT name FROM products WHERE id = $product_id")->fetch_assoc()['name'];
        $stmt = $conn->prepare("INSERT INTO materials (name, type, category, unit, quantity, unit_price)
                               VALUES (?, 'finished', 'direct', 'unit', ?, ?)
                               ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)");
        $stmt->bind_param("sid", $product_name, $quantity, $cost_per_unit);
        $stmt->execute();
        
        // Commit transaction
        $conn->commit();
        
        header("Location: costing.php?product_id=$product_id&success=COGM calculated and saved successfully");
    } catch (Exception $e) {
        // Rollback on error
        $conn->rollback();
        header("Location: costing.php?product_id=$product_id&error=Error calculating COGM: " . $e->getMessage());
    }
} else {
    header("Location: costing.php");
}
?>