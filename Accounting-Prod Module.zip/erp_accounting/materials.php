<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Materials & Costs - Production ERP System</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <?php include 'header.php'; ?>
        
        <main>
            <div class="page-header">
                <h2><i class="fas fa-cubes"></i> Materials & Costs Management</h2>
                <div class="breadcrumb">
                    <span>Home</span> / <span class="active">Materials & Costs</span>
                </div>
            </div>
            
            <!-- Tabs -->
            <div class="tabs">
                <button class="tab-btn active" data-tab="materials">Materials</button>
                <button class="tab-btn" data-tab="labor">Labor Costs</button>
                <button class="tab-btn" data-tab="overhead">Overhead Costs</button>
                <?php if (isset($_GET['action']) && $_GET['action'] == 'add'): ?>
                    <button class="tab-btn" data-tab="add-material">Add Material</button>
                <?php endif; ?>
            </div>
            
            <!-- Tab Contents -->
            <div class="tab-content active" id="materials">
                <div class="card">
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Material Name</th>
                                    <th>Type</th>
                                    <th>Category</th>
                                    <th>Unit</th>
                                    <th>Quantity</th>
                                    <th>Unit Price</th>
                                    <th>Total Value</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT * FROM materials";
                                $result = $conn->query($query);
                                
                                while($row = $result->fetch_assoc()):
                                ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo ucfirst($row['type']); ?></td>
                                    <td><?php echo ucfirst($row['category']); ?></td>
                                    <td><?php echo $row['unit']; ?></td>
                                    <td><?php echo $row['quantity']; ?></td>
                                    <td>Rp <?php echo number_format($row['unit_price'], 2); ?></td>
                                    <td>Rp <?php echo number_format($row['quantity'] * $row['unit_price'], 2); ?></td>
                                    <td>
                                        <a href="materials.php?action=edit&id=<?php echo $row['id']; ?>" class="btn btn-sm">Edit</a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-right mt-3">
                        <a href="materials.php?action=add" class="btn">Add Material</a>
                    </div>
                </div>
            </div>
            
            <div class="tab-content <?php echo (isset($_GET['tab']) && $_GET['tab'] == 'labor') ? 'active' : '' ?>" id="labor">
    <div class="card">
        <h3>Labor Costs</h3>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Labor Name</th>
                        <th>Category</th>
                        <th>Hourly Rate</th>
                        <th>Hours/Unit</th>
                        <th>Cost/Unit</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT * FROM labor_costs";
                    $result = $conn->query($query);
                    
                    while($row = $result->fetch_assoc()):
                    ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo ucfirst($row['category']); ?></td>
                        <td>Rp <?php echo number_format($row['hourly_rate'], 2); ?></td>
                        <td><?php echo $row['hours_per_unit']; ?></td>
                        <td>Rp <?php echo number_format($row['hourly_rate'] * $row['hours_per_unit'], 2); ?></td>
                        <td>
                            <button onclick="openLaborModal('edit', <?php echo $row['id']; ?>)" 
                                    class="btn btn-sm">Edit</button>
                            <a href="process_labor.php?delete=1&id=<?php echo $row['id']; ?>" 
                               class="btn btn-sm btn-danger" 
                               onclick="return confirm('Delete this labor cost?')">Delete</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <div class="text-right mt-3">
            <button onclick="openLaborModal('add')" class="btn">Add Labor Cost</button>
        </div>
    </div>
</div>
            
            <div class="tab-content <?php echo (isset($_GET['tab']) && $_GET['tab'] == 'overhead') ? 'active' : '' ?>" id="overhead">
    <div class="card">
        <h3>Overhead Costs</h3>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Cost Name</th>
                        <th>Category</th>
                        <th>Amount</th>
                        <th>Allocation Base</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT * FROM overhead_costs";
                    $result = $conn->query($query);
                    
                    while($row = $result->fetch_assoc()):
                    ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['name']; ?></td>
                        <td>Overhead</td>
                        <td>Rp <?php echo number_format($row['amount'], 2); ?></td>
                        <td><?php echo $row['allocation_base']; ?></td>
                        <td>
                            <button onclick="openOverheadModal('edit', <?php echo $row['id']; ?>)" 
                                    class="btn btn-sm">Edit</button>
                            <a href="process_overhead.php?delete=1&id=<?php echo $row['id']; ?>" 
                               class="btn btn-sm btn-danger" 
                               onclick="return confirm('Delete this overhead cost?')">Delete</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <div class="text-right mt-3">
            <button onclick="openOverheadModal('add')" class="btn">Add Overhead Cost</button>
        </div>
    </div>
</div>


            
            <?php if(isset($_GET['action']) && ($_GET['action'] == 'add' || $_GET['action'] == 'edit')): ?>
            <div class="tab-content <?php echo isset($_GET['action']) ? 'active' : ''; ?>" id="add-material">
                <div class="card">
                    <h3><?php echo $_GET['action'] == 'add' ? 'Add New Material' : 'Edit Material'; ?></h3>
                    <form action="process_material.php" method="POST">
                        <?php if($_GET['action'] == 'edit' && isset($_GET['id'])): 
                            $material_id = $_GET['id'];
                            $query = "SELECT * FROM materials WHERE id = $material_id";
                            $result = $conn->query($query);
                            $material = $result->fetch_assoc();
                        ?>
                            <input type="hidden" name="action" value="edit">
                            <input type="hidden" name="material_id" value="<?php echo $material_id; ?>">
                        <?php else: ?>
                            <input type="hidden" name="action" value="add">
                        <?php endif; ?>
                        
                        <div class="form-group">
                            <label for="name">Material Name</label>
                            <input type="text" class="form-control" id="name" name="name" 
                                   value="<?php echo isset($material) ? $material['name'] : ''; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="type">Material Type</label>
                            <select class="form-control" id="type" name="type" required>
                                <option value="raw" <?php echo isset($material) && $material['type'] == 'raw' ? 'selected' : ''; ?>>Raw Material</option>
                                <option value="finished" <?php echo isset($material) && $material['type'] == 'finished' ? 'selected' : ''; ?>>Finished Good</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="category">Cost Category</label>
                            <select class="form-control" id="category" name="category" required>
                                <option value="direct" <?php echo isset($material) && $material['category'] == 'direct' ? 'selected' : ''; ?>>Direct Material</option>
                                <option value="indirect" <?php echo isset($material) && $material['category'] == 'indirect' ? 'selected' : ''; ?>>Indirect Material</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="unit">Unit</label>
                            <input type="text" class="form-control" id="unit" name="unit" 
                                   value="<?php echo isset($material) ? $material['unit'] : ''; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="quantity">Quantity</label>
                            <input type="number" step="0.01" class="form-control" id="quantity" name="quantity" 
                                   value="<?php echo isset($material) ? $material['quantity'] : ''; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="unit_price">Unit Price (Rp)</label>
                            <input type="number" step="0.01" class="form-control" id="unit_price" name="unit_price" 
                                   value="<?php echo isset($material) ? $material['unit_price'] : ''; ?>" required>
                        </div>
                        
                        <div class="text-right">
                            <button type="submit" class="btn"><?php echo $_GET['action'] == 'add' ? 'Add Material' : 'Update Material'; ?></button>
                        </div>
                    </form>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if(isset($_GET['action']) && ($_GET['action'] == 'add_labor' || $_GET['action'] == 'edit_labor')): ?>
            <div class="tab-content <?php echo isset($_GET['action']) ? 'active' : ''; ?>" id="add-labor">
                <div class="card">
                    <h3><?php echo $_GET['action'] == 'add_labor' ? 'Add New Labor Cost' : 'Edit Labor Cost'; ?></h3>
                    <form action="process_labor.php" method="POST">
                        <?php if($_GET['action'] == 'edit_labor' && isset($_GET['id'])): 
                            $labor_id = $_GET['id'];
                            $query = "SELECT * FROM labor_costs WHERE id = $labor_id";
                            $result = $conn->query($query);
                            $labor = $result->fetch_assoc();
                        ?>
                            <input type="hidden" name="action" value="edit">
                            <input type="hidden" name="labor_id" value="<?php echo $labor_id; ?>">
                        <?php else: ?>
                            <input type="hidden" name="action" value="add">
                        <?php endif; ?>
                        
                        <div class="form-group">
                            <label for="name">Labor Name</label>
                            <input type="text" class="form-control" id="name" name="name" 
                                   value="<?php echo isset($labor) ? $labor['name'] : ''; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="category">Cost Category</label>
                            <select class="form-control" id="category" name="category" required>
                                <option value="direct" <?php echo isset($labor) && $labor['category'] == 'direct' ? 'selected' : ''; ?>>Direct Labor</option>
                                <option value="indirect" <?php echo isset($labor) && $labor['category'] == 'indirect' ? 'selected' : ''; ?>>Indirect Labor</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="hourly_rate">Hourly Rate (Rp)</label>
                            <input type="number" step="0.01" class="form-control" id="hourly_rate" name="hourly_rate" 
                                   value="<?php echo isset($labor) ? $labor['hourly_rate'] : ''; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="hours_per_unit">Hours per Unit</label>
                            <input type="number" step="0.01" class="form-control" id="hours_per_unit" name="hours_per_unit" 
                                   value="<?php echo isset($labor) ? $labor['hours_per_unit'] : ''; ?>" required>
                        </div>
                        
                        <div class="text-right">
                            <button type="submit" class="btn"><?php echo $_GET['action'] == 'add_labor' ? 'Add Labor Cost' : 'Update Labor Cost'; ?></button>
                        </div>
                    </form>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if(isset($_GET['action']) && ($_GET['action'] == 'add_overhead' || $_GET['action'] == 'edit_overhead')): ?>
            <div class="tab-content <?php echo isset($_GET['action']) ? 'active' : ''; ?>" id="add-overhead">
                <div class="card">
                    <h3><?php echo $_GET['action'] == 'add_overhead' ? 'Add New Overhead Cost' : 'Edit Overhead Cost'; ?></h3>
                    <form action="process_overhead.php" method="POST">
                        <?php if($_GET['action'] == 'edit_overhead' && isset($_GET['id'])): 
                            $overhead_id = $_GET['id'];
                            $query = "SELECT * FROM overhead_costs WHERE id = $overhead_id";
                            $result = $conn->query($query);
                            $overhead = $result->fetch_assoc();
                        ?>
                            <input type="hidden" name="action" value="edit">
                            <input type="hidden" name="overhead_id" value="<?php echo $overhead_id; ?>">
                        <?php else: ?>
                            <input type="hidden" name="action" value="add">
                        <?php endif; ?>
                        
                        <div class="form-group">
                            <label for="name">Overhead Name</label>
                            <input type="text" class="form-control" id="name" name="name" 
                                   value="<?php echo isset($overhead) ? $overhead['name'] : ''; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="amount">Amount (Rp)</label>
                            <input type="number" step="0.01" class="form-control" id="amount" name="amount" 
                                   value="<?php echo isset($overhead) ? $overhead['amount'] : ''; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="allocation_base">Allocation Base</label>
                            <input type="text" class="form-control" id="allocation_base" name="allocation_base" 
                                   value="<?php echo isset($overhead) ? $overhead['allocation_base'] : ''; ?>" required>
                        </div>
                        
                        <div class="text-right">
                            <button type="submit" class="btn"><?php echo $_GET['action'] == 'add_overhead' ? 'Add Overhead Cost' : 'Update Overhead Cost'; ?></button>
                        </div>
                    </form>
                </div>
            </div>
            <?php endif; ?>
        
            <!-- Modal Structure -->
<div id="laborModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="laborModalTitle">Add Labor Cost</h3>
            <span class="close">&times;</span>
        </div>
        <div class="modal-body">
            <form id="laborForm" action="process_labor.php" method="POST">
                <input type="hidden" name="action" id="laborAction" value="add">
                <input type="hidden" name="labor_id" id="laborId" value="">
                
                <div class="form-group">
                    <label for="laborName">Labor Name</label>
                    <input type="text" class="form-control" id="laborName" name="name" required>
                </div>
                
                <div class="form-group">
                    <label for="laborCategory">Category</label>
                    <select class="form-control" id="laborCategory" name="category" required>
                        <option value="direct">Direct Labor</option>
                        <option value="indirect">Indirect Labor</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="laborRate">Hourly Rate (Rp)</label>
                    <input type="number" step="0.01" class="form-control" id="laborRate" name="hourly_rate" required>
                </div>
                
                <div class="form-group">
                    <label for="laborHours">Hours per Unit</label>
                    <input type="number" step="0.01" class="form-control" id="laborHours" name="hours_per_unit" required>
                </div>
                
                <div class="text-right">
                    <button type="submit" class="btn">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="overheadModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="overheadModalTitle">Add Overhead Cost</h3>
            <span class="close">&times;</span>
        </div>
        <div class="modal-body">
            <form id="overheadForm" action="process_overhead.php" method="POST">
                <input type="hidden" name="action" id="overheadAction" value="add">
                <input type="hidden" name="overhead_id" id="overheadId" value="">
                
                <div class="form-group">
                    <label for="overheadName">Cost Name</label>
                    <input type="text" class="form-control" id="overheadName" name="name" required>
                </div>
                
                <div class="form-group">
                    <label for="overheadAmount">Amount (Rp)</label>
                    <input type="number" step="0.01" class="form-control" id="overheadAmount" name="amount" required>
                </div>
                
                <div class="form-group">
                    <label for="overheadAllocation">Allocation Base</label>
                    <input type="text" class="form-control" id="overheadAllocation" name="allocation_base" required>
                </div>
                
                <div class="text-right">
                    <button type="submit" class="btn">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
        </main>
    </div>
    
    <script src="assets/js/script.js"></script>
    <script>
        // Tab functionality
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                // Remove active class from all tabs and contents
                document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                
                // Add active class to clicked tab
                btn.classList.add('active');
                const tabId = btn.getAttribute('data-tab');
                document.getElementById(tabId).classList.add('active');
            });
        });
    </script>
    <script>
// Modal functionality
function openLaborModal(action = 'add', id = null) {
    const modal = document.getElementById('laborModal');
    const title = document.getElementById('laborModalTitle');
    
    if(action === 'edit' && id) {
        fetch(`get_labor.php?id=${id}`)
            .then(response => response.json())
            .then(data => {
                document.getElementById('laborName').value = data.name;
                document.getElementById('laborCategory').value = data.category;
                document.getElementById('laborRate').value = data.hourly_rate;
                document.getElementById('laborHours').value = data.hours_per_unit;
                document.getElementById('laborId').value = id;
                document.getElementById('laborAction').value = 'edit';
                title.textContent = 'Edit Labor Cost';
                modal.style.display = 'flex';
            });
    } else {
        document.getElementById('laborForm').reset();
        document.getElementById('laborAction').value = 'add';
        document.getElementById('laborId').value = '';
        title.textContent = 'Add Labor Cost';
        modal.style.display = 'flex';
    }
}

// Function to open overhead modal
function openOverheadModal(action = 'add', id = null) {
    const modal = document.getElementById('overheadModal');
    const title = document.getElementById('overheadModalTitle');
    
    if(action === 'edit' && id) {
        fetch(`get_overhead.php?id=${id}`)
            .then(response => response.json())
            .then(data => {
                document.getElementById('overheadName').value = data.name;
                document.getElementById('overheadAmount').value = data.amount;
                document.getElementById('overheadAllocation').value = data.allocation_base;
                document.getElementById('overheadId').value = id;
                document.getElementById('overheadAction').value = 'edit';
                title.textContent = 'Edit Overhead Cost';
                modal.style.display = 'flex';
            });
    } else {
        document.getElementById('overheadForm').reset();
        document.getElementById('overheadAction').value = 'add';
        document.getElementById('overheadId').value = '';
        title.textContent = 'Add Overhead Cost';
        modal.style.display = 'flex';
    }
}

// Close modals
document.querySelectorAll('.close').forEach(btn => {
    btn.addEventListener('click', function() {
        this.closest('.modal').style.display = 'none';
    });
});

window.addEventListener('click', function(event) {
    if(event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
});

// Edit button functionality
function editLabor(id) {
    openLaborModal('edit', id);
}

function editOverhead(id) {
    openOverheadModal('edit', id);
}
</script>
</body>
</html>