<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Production Costing - Production ERP System</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <?php include 'header.php'; ?>
        
        <main>
            <div class="page-header">
                <h2><i class="fas fa-calculator"></i> Production Costing</h2>
                <div class="breadcrumb">
                    <span>Home</span> / <span class="active">Production Costing</span>
                </div>
            </div>
            
            <?php
            // Get product details if product_id is provided
            $product_id = isset($_GET['product_id']) ? intval($_GET['product_id']) : 0;
            $product = null;
            $materials = [];
            $labor_costs = [];
            
            if($product_id > 0) {
                // Get product info
                $query = "SELECT * FROM products WHERE id = $product_id";
                $result = $conn->query($query);
                $product = $result->fetch_assoc();
                
                // Get materials for this product
                $query = "SELECT m.*, pm.quantity as required_quantity 
                          FROM product_materials pm
                          JOIN materials m ON pm.material_id = m.id
                          WHERE pm.product_id = $product_id";
                $result = $conn->query($query);
                while($row = $result->fetch_assoc()) {
                    $materials[] = $row;
                }
                
                // Get labor costs
                $query = "SELECT * FROM labor_costs";
                $result = $conn->query($query);
                while($row = $result->fetch_assoc()) {
                    $labor_costs[] = $row;
                }
            }
            ?>
            
            <div class="card">
                <h3>Select Product</h3>
                <form method="GET" action="costing.php">
                    <div class="form-group">
                        <label for="product_id">Product</label>
                        <select class="form-control" id="product_id" name="product_id" required onchange="this.form.submit()">
                            <option value="">-- Select Product --</option>
                            <?php
                            $query = "SELECT * FROM products";
                            $result = $conn->query($query);
                            while($row = $result->fetch_assoc()):
                            ?>
                            <option value="<?php echo $row['id']; ?>" <?php echo $product_id == $row['id'] ? 'selected' : ''; ?>>
                                <?php echo $row['name']; ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </form>
            </div>
            
            <?php if($product_id > 0): ?>
            <div class="card">
                <h3>Product Cost Calculation: <?php echo $product['name']; ?></h3>
                
                <form action="process_costing.php" method="POST">
                    <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                    
                    <h4>Direct Materials</h4>
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Material</th>
                                    <th>Category</th>
                                    <th>Required Quantity</th>
                                    <th>Unit Price</th>
                                    <th>Total Cost</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $total_direct_materials = 0;
                                $total_indirect_materials = 0;
                                
                                foreach($materials as $material):
                                    $total_cost = $material['required_quantity'] * $material['unit_price'];
                                    
                                    if($material['category'] == 'direct') {
                                        $total_direct_materials += $total_cost;
                                    } else {
                                        $total_indirect_materials += $total_cost;
                                    }
                                ?>
                                <tr>
                                    <td><?php echo $material['name']; ?></td>
                                    <td><?php echo ucfirst($material['category']); ?></td>
                                    <td><?php echo $material['required_quantity'] . ' ' . $material['unit']; ?></td>
                                    <td>Rp <?php echo number_format($material['unit_price'], 2); ?></td>
                                    <td>Rp <?php echo number_format($total_cost, 2); ?></td>
                                </tr>
                                <?php endforeach; ?>
                                <tr class="total-row">
                                    <td colspan="4" class="text-right"><strong>Total Direct Materials:</strong></td>
                                    <td><strong>Rp <?php echo number_format($total_direct_materials, 2); ?></strong></td>
                                </tr>
                                <tr class="total-row">
                                    <td colspan="4" class="text-right"><strong>Total Indirect Materials:</strong></td>
                                    <td><strong>Rp <?php echo number_format($total_indirect_materials, 2); ?></strong></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    
                    <h4>Labor Costs</h4>
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Labor</th>
                                    <th>Category</th>
                                    <th>Hourly Rate</th>
                                    <th>Hours per Unit</th>
                                    <th>Cost per Unit</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $total_direct_labor = 0;
                                $total_indirect_labor = 0;
                                
                                foreach($labor_costs as $labor):
                                    $cost_per_unit = $labor['hourly_rate'] * $labor['hours_per_unit'];
                                    
                                    if($labor['category'] == 'direct') {
                                        $total_direct_labor += $cost_per_unit;
                                    } else {
                                        $total_indirect_labor += $cost_per_unit;
                                    }
                                ?>
                                <tr>
                                    <td><?php echo $labor['name']; ?></td>
                                    <td><?php echo ucfirst($labor['category']); ?></td>
                                    <td>Rp <?php echo number_format($labor['hourly_rate'], 2); ?></td>
                                    <td><?php echo $labor['hours_per_unit']; ?></td>
                                    <td>Rp <?php echo number_format($cost_per_unit, 2); ?></td>
                                </tr>
                                <?php endforeach; ?>
                                <tr class="total-row">
                                    <td colspan="4" class="text-right"><strong>Total Direct Labor:</strong></td>
                                    <td><strong>Rp <?php echo number_format($total_direct_labor, 2); ?></strong></td>
                                </tr>
                                <tr class="total-row">
                                    <td colspan="4" class="text-right"><strong>Total Indirect Labor:</strong></td>
                                    <td><strong>Rp <?php echo number_format($total_indirect_labor, 2); ?></strong></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    
                    <h4>Overhead Allocation</h4>
                    <div class="form-group">
                        <label for="production_quantity">Production Quantity</label>
                        <input type="number" class="form-control" id="production_quantity" name="production_quantity" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="overhead_allocation">Overhead Allocation (Rp)</label>
                        <input type="number" step="0.01" class="form-control" id="overhead_allocation" name="overhead_allocation" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="markup_percentage">Markup Percentage (%)</label>
                        <input type="number" step="0.01" class="form-control" id="markup_percentage" name="markup_percentage" value="50" required>
                    </div>
                    
                    <div class="text-right">
                        <button type="submit" class="btn">Calculate Production Cost</button>
                    </div>
                </form>
            </div>
            <?php endif; ?>
            
            <!-- Previous Production Runs -->
            <div class="card mt-4">
    <h3>Saved Cost Calculations</h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Quantity</th>
                    <th>Direct Materials</th>
                    <th>Direct Labor</th>
                    <th>Overhead</th>
                    <th>Total Cost</th>
                    <th>Cost/Unit</th>
                    <th>Markup</th>
                    <th>Selling Price</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if($product_id > 0) {
                    $query = "SELECT * FROM product_costing 
                              WHERE product_id = $product_id 
                              ORDER BY created_at DESC";
                    $result = $conn->query($query);
                    
                    while($row = $result->fetch_assoc()):
                ?>
                <tr>
                    <td><?= date('d M Y', strtotime($row['created_at'])) ?></td>
                    <td><?= $row['production_quantity'] ?></td>
                    <td>Rp <?= number_format($row['direct_materials'], 2) ?></td>
                    <td>Rp <?= number_format($row['direct_labor'], 2) ?></td>
                    <td>Rp <?= number_format($row['manufacturing_overhead'], 2) ?></td>
                    <td>Rp <?= number_format($row['total_cost'], 2) ?></td>
                    <td>Rp <?= number_format($row['cost_per_unit'], 2) ?></td>
                    <td><?= $row['markup_percentage'] ?>%</td>
                    <td>Rp <?= number_format($row['selling_price'], 2) ?></td>
                </tr>
                <?php
                    endwhile;
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
    
    <script src="assets/js/script.js"></script>
</body>
</html>