<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "erp_accounting";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create tables if they don't exist
$sql = "
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS materials (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type ENUM('raw', 'finished') NOT NULL,
    category ENUM('direct', 'indirect') NOT NULL,
    unit VARCHAR(20) NOT NULL,
    quantity DECIMAL(10,2) NOT NULL DEFAULT 0,
    unit_price DECIMAL(12,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS product_materials (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    material_id INT NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (product_id) REFERENCES products(id),
    FOREIGN KEY (material_id) REFERENCES materials(id)
);

CREATE TABLE IF NOT EXISTS labor_costs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category ENUM('direct', 'indirect') NOT NULL,
    hourly_rate DECIMAL(10,2) NOT NULL,
    hours_per_unit DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS overhead_costs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    allocation_base VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS production_runs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    total_cost DECIMAL(12,2) NOT NULL,
    cost_per_unit DECIMAL(12,2) NOT NULL,
    selling_price DECIMAL(12,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE IF NOT EXISTS overhead_allocations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    overhead_id INT NOT NULL,
    product_id INT NOT NULL,
    allocation_base VARCHAR(100) NOT NULL,
    allocation_percentage DECIMAL(5,2) NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (overhead_id) REFERENCES overhead_costs(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE IF NOT EXISTS product_costing (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    production_quantity INT NOT NULL,
    direct_materials DECIMAL(12,2) NOT NULL,
    direct_labor DECIMAL(12,2) NOT NULL,
    manufacturing_overhead DECIMAL(12,2) NOT NULL,
    total_cost DECIMAL(12,2) NOT NULL,
    cost_per_unit DECIMAL(12,2) NOT NULL,
    markup_percentage DECIMAL(5,2) NOT NULL,
    selling_price DECIMAL(12,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE IF NOT EXISTS product_costing (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    production_quantity INT NOT NULL,
    direct_materials DECIMAL(12,2) NOT NULL,
    direct_labor DECIMAL(12,2) NOT NULL,
    indirect_materials DECIMAL(12,2) NOT NULL,
    indirect_labor DECIMAL(12,2) NOT NULL,
    allocated_overhead DECIMAL(12,2) NOT NULL,
    manufacturing_overhead DECIMAL(12,2) NOT NULL,
    total_direct_cost DECIMAL(12,2) NOT NULL,
    total_cost DECIMAL(12,2) NOT NULL,
    cost_per_unit DECIMAL(12,2) NOT NULL,
    markup_percentage DECIMAL(5,2) NOT NULL,
    selling_price DECIMAL(12,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

";

if ($conn->multi_query($sql) === TRUE) {
    // Tables created successfully
} else {
    echo "Error creating tables: " . $conn->error;
}

// Close multi_query connection
while ($conn->next_result()) {;}
?>