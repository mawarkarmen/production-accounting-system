<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Production ERP System</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <?php include 'header.php'; ?>
        
        <main>
            <div class="page-header">
                <h2><i class="fas fa-box"></i> Product Management</h2>
                <div class="breadcrumb">
                    <span>Home</span> / <span class="active">Products</span>
                </div>
            </div>
            
            <!-- Tabs -->
            <div class="tabs">
                <button class="tab-btn <?php echo (!isset($_GET['tab']) || $_GET['tab'] == 'products') ? 'active' : '' ?>" 
                        onclick="window.location.href='products.php?tab=products'">Products</button>
                <button class="tab-btn <?php echo (isset($_GET['tab']) && $_GET['tab'] == 'raw-materials') ? 'active' : '' ?>" 
                        onclick="window.location.href='products.php?tab=raw-materials'">Raw Materials</button>
                <button class="tab-btn <?php echo (isset($_GET['tab']) && $_GET['tab'] == 'finished-goods') ? 'active' : '' ?>" 
                        onclick="window.location.href='products.php?tab=finished-goods'">Finished Goods</button>
            </div>
            
            <!-- Products Tab -->
            <div class="tab-content <?php echo (!isset($_GET['tab']) || $_GET['tab'] == 'products') ? 'active' : '' ?>" id="products">
                <div class="card">
                    <div class="table-responsive">
                        <table id="products-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Product Name</th>
                                    <th>Description</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT * FROM products";
                                $result = $conn->query($query);
                                
                                while($row = $result->fetch_assoc()):
                                ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo substr($row['description'], 0, 50) . '...'; ?></td>
                                    <td>
                                        <button onclick="openProductModal('edit', <?php echo $row['id']; ?>)" 
                                                class="btn btn-sm">Edit</button>
                                        <a href="process_product.php?delete=1&id=<?php echo $row['id']; ?>" 
                                           class="btn btn-sm btn-danger" 
                                           onclick="return confirm('Are you sure you want to delete this product?')">Delete</a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-right mt-3">
                        <button onclick="openProductModal('add')" class="btn">Add Product</button>
                    </div>
                </div>
            </div>
            
            <!-- Raw Materials Tab -->
            <div class="tab-content <?php echo (isset($_GET['tab']) && $_GET['tab'] == 'raw-materials') ? 'active' : '' ?>" id="raw-materials">
                <div class="card">
                    <h3>Raw Materials Inventory</h3>
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Material Name</th>
                                    <th>Type</th>
                                    <th>Category</th>
                                    <th>Quantity</th>
                                    <th>Unit Price</th>
                                    <th>Total Value</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT * FROM materials WHERE type = 'raw'";
                                $result = $conn->query($query);
                                
                                while($row = $result->fetch_assoc()):
                                ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo ucfirst($row['type']); ?></td>
                                    <td><?php echo ucfirst($row['category']); ?></td>
                                    <td><?php echo $row['quantity'] . ' ' . $row['unit']; ?></td>
                                    <td>Rp <?php echo number_format($row['unit_price'], 2); ?></td>
                                    <td>Rp <?php echo number_format($row['quantity'] * $row['unit_price'], 2); ?></td>
                                    <td>
                                        <button onclick="openMaterialModal('edit', <?php echo $row['id']; ?>)" 
                                                class="btn btn-sm">Edit</button>
                                        <a href="process_material.php?delete=1&id=<?php echo $row['id']; ?>" 
                                           class="btn btn-sm btn-danger" 
                                           onclick="return confirm('Are you sure you want to delete this material?')">Delete</a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-right mt-3">
                        <button onclick="openMaterialModal('add')" class="btn">Add Material</button>
                    </div>
                </div>
            </div>
            
            <!-- Finished Goods Tab -->
            <div class="tab-content <?php echo (isset($_GET['tab']) && $_GET['tab'] == 'finished-goods') ? 'active' : ''; ?>" id="finished-goods">
                <div class="card">
                    <h3>Finished Goods Inventory</h3>
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Product Name</th>
                                    <th>Quantity</th>
                                    <th>Unit Cost</th>
                                    <th>Total Value</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT p.id, p.name, 
                                         IFNULL(SUM(pr.quantity), 0) as quantity,
                                         IFNULL(AVG(pr.cost_per_unit), 0) as unit_cost
                                         FROM products p
                                         LEFT JOIN production_runs pr ON p.id = pr.product_id
                                         GROUP BY p.id";
                                $result = $conn->query($query);
                                
                                while($row = $result->fetch_assoc()):
                                ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo $row['quantity']; ?></td>
                                    <td>Rp <?php echo number_format($row['unit_cost'], 2); ?></td>
                                    <td>Rp <?php echo number_format($row['quantity'] * $row['unit_cost'], 2); ?></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
        
        <!-- Product Modal -->
        <div id="productModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 id="productModalTitle">Add Product</h3>
                    <span class="close">&times;</span>
                </div>
                <div class="modal-body">
                    <form id="productForm" action="process_product.php" method="POST">
                        <input type="hidden" name="action" id="productAction" value="add">
                        <input type="hidden" name="product_id" id="productId" value="">
                        
                        <div class="form-group">
                            <label for="productName">Product Name</label>
                            <input type="text" class="form-control" id="productName" name="name" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="productDescription">Description</label>
                            <textarea class="form-control" id="productDescription" name="description" rows="3"></textarea>
                        </div>
                        
                        <h4>Required Materials</h4>
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Material</th>
                                        <th>Category</th>
                                        <th>Unit</th>
                                        <th>Current Stock</th>
                                        <th>Required Quantity</th>
                                    </tr>
                                </thead>
                                <tbody id="materialSelection">
                                    <?php
                                    $materials = $conn->query("SELECT * FROM materials WHERE type = 'raw'");
                                    while($material = $materials->fetch_assoc()):
                                    ?>
                                    <tr>
                                        <td><?php echo $material['name']; ?></td>
                                        <td><?php echo ucfirst($material['category']); ?></td>
                                        <td><?php echo $material['unit']; ?></td>
                                        <td><?php echo $material['quantity']; ?></td>
                                        <td>
                                            <input type="number" step="0.01" class="form-control" 
                                                   name="materials[<?php echo $material['id']; ?>]" 
                                                   value="0" min="0">
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="text-right mt-3">
                            <button type="submit" class="btn">Save Product</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Material Modal -->
        <div id="materialModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 id="materialModalTitle">Add Material</h3>
                    <span class="close">&times;</span>
                </div>
                <div class="modal-body">
                    <form id="materialForm" action="process_material.php" method="POST">
                        <input type="hidden" name="action" id="materialAction" value="add">
                        <input type="hidden" name="material_id" id="materialId" value="">
                        
                        <div class="form-group">
                            <label for="materialName">Material Name</label>
                            <input type="text" class="form-control" id="materialName" name="name" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="materialType">Material Type</label>
                            <select class="form-control" id="materialType" name="type" required>
                                <option value="raw">Raw Material</option>
                                <option value="finished">Finished Good</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="materialCategory">Cost Category</label>
                            <select class="form-control" id="materialCategory" name="category" required>
                                <option value="direct">Direct Material</option>
                                <option value="indirect">Indirect Material</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="materialUnit">Unit</label>
                            <input type="text" class="form-control" id="materialUnit" name="unit" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="materialQuantity">Quantity</label>
                            <input type="number" step="0.01" class="form-control" id="materialQuantity" name="quantity" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="materialUnitPrice">Unit Price (Rp)</label>
                            <input type="number" step="0.01" class="form-control" id="materialUnitPrice" name="unit_price" required>
                        </div>
                        
                        <div class="text-right">
                            <button type="submit" class="btn">Save Material</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script src="assets/js/script.js"></script>
    <script>
        // Product Modal Functions
        function openProductModal(action = 'add', id = null) {
            const modal = document.getElementById('productModal');
            const title = document.getElementById('productModalTitle');
            const form = document.getElementById('productForm');
            
            if(action === 'edit' && id) {
                // Fetch existing product data
                fetch(`get_product.php?id=${id}`)
                    .then(response => response.json())
                    .then(product => {
                        document.getElementById('productName').value = product.name;
                        document.getElementById('productDescription').value = product.description;
                        document.getElementById('productId').value = id;
                        document.getElementById('productAction').value = 'edit';
                        title.textContent = 'Edit Product';
                        
                        // Fetch material requirements for this product
                        return fetch(`get_product_materials.php?product_id=${id}`);
                    })
                    .then(response => response.json())
                    .then(materials => {
                        materials.forEach(material => {
                            const input = document.querySelector(`input[name="materials[${material.material_id}]"]`);
                            if(input) input.value = material.quantity;
                        });
                    });
            } else {
                // Reset form for add
                form.reset();
                document.getElementById('productAction').value = 'add';
                title.textContent = 'Add Product';
                
                // Reset all material quantities to 0
                document.querySelectorAll('#materialSelection input').forEach(input => {
                    input.value = 0;
                });
            }
            
            modal.style.display = 'flex';
        }
        
        // Material Modal Functions
        function openMaterialModal(action = 'add', id = null) {
            const modal = document.getElementById('materialModal');
            const title = document.getElementById('materialModalTitle');
            const form = document.getElementById('materialForm');
            
            if(action === 'edit' && id) {
                // Fetch existing material data
                fetch(`get_material.php?id=${id}`)
                    .then(response => response.json())
                    .then(material => {
                        document.getElementById('materialName').value = material.name;
                        document.getElementById('materialType').value = material.type;
                        document.getElementById('materialCategory').value = material.category;
                        document.getElementById('materialUnit').value = material.unit;
                        document.getElementById('materialQuantity').value = material.quantity;
                        document.getElementById('materialUnitPrice').value = material.unit_price;
                        document.getElementById('materialId').value = id;
                        document.getElementById('materialAction').value = 'edit';
                        title.textContent = 'Edit Material';
                    });
            } else {
                // Reset form for add
                form.reset();
                document.getElementById('materialAction').value = 'add';
                title.textContent = 'Add Material';
            }
            
            modal.style.display = 'flex';
        }
        
        // Close modals when clicking X
        document.querySelectorAll('.close').forEach(closeBtn => {
            closeBtn.addEventListener('click', function() {
                this.closest('.modal').style.display = 'none';
            });
        });
        
        // Close modals when clicking outside
        window.addEventListener('click', function(event) {
            if(event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        });
    </script>
</body>
</html>