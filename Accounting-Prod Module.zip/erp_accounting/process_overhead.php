<?php
require_once 'config.php';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];
    $name = $conn->real_escape_string($_POST['name']);
    $amount = floatval($_POST['amount']);
    $allocation_base = $conn->real_escape_string($_POST['allocation_base']);
    
    if($action == 'add') {
        $stmt = $conn->prepare("INSERT INTO overhead_costs (name, amount, allocation_base) VALUES (?, ?, ?)");
        $stmt->bind_param("sds", $name, $amount, $allocation_base);
        
        if($stmt->execute()) {
            header("Location: materials.php?tab=overhead&success=Overhead cost added successfully");
        } else {
            header("Location: materials.php?tab=overhead&error=Error adding overhead cost");
        }
    } elseif($action == 'edit') {
        $overhead_id = intval($_POST['overhead_id']);
        $stmt = $conn->prepare("UPDATE overhead_costs SET name = ?, amount = ?, allocation_base = ? WHERE id = ?");
        $stmt->bind_param("sdsi", $name, $amount, $allocation_base, $overhead_id);
        
        if($stmt->execute()) {
            header("Location: materials.php?tab=overhead&success=Overhead cost updated successfully");
        } else {
            header("Location: materials.php?tab=overhead&error=Error updating overhead cost");
        }
    }
} elseif(isset($_GET['delete'])) {
    $overhead_id = intval($_GET['id']);

    // First delete from overhead_allocations
    $conn->query("DELETE FROM overhead_allocations WHERE overhead_id = $overhead_id");

    // Then delete from overhead_costs
    if($conn->query("DELETE FROM overhead_costs WHERE id = $overhead_id")) {
        header("Location: materials.php?tab=overhead&success=Overhead cost deleted successfully");
    } else {
        header("Location: materials.php?tab=overhead&error=Error deleting overhead cost");
    }
}
?>