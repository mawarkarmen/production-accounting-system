<?php
require_once 'config.php';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];
    $name = $_POST['name'];
    $type = $_POST['type'];
    $category = $_POST['category'];
    $unit = $_POST['unit'];
    $quantity = $_POST['quantity'];
    $unit_price = $_POST['unit_price'];
    
    if($action == 'add') {
        // Insert new material
        $stmt = $conn->prepare("INSERT INTO materials (name, type, category, unit, quantity, unit_price) 
                              VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssdd", $name, $type, $category, $unit, $quantity, $unit_price);
        
        if($stmt->execute()) {
            header("Location: materials.php?success=Material added successfully");
        } else {
            header("Location: materials.php?error=Error adding material");
        }
    } elseif($action == 'edit') {
        // Update existing material
        $material_id = $_POST['material_id'];
        $stmt = $conn->prepare("UPDATE materials SET name = ?, type = ?, category = ?, unit = ?, 
                              quantity = ?, unit_price = ? WHERE id = ?");
        $stmt->bind_param("ssssddi", $name, $type, $category, $unit, $quantity, $unit_price, $material_id);
        
        if($stmt->execute()) {
            header("Location: materials.php?success=Material updated successfully");
        } else {
            header("Location: materials.php?error=Error updating material");
        }
    }
} elseif(isset($_GET['delete'])) {
    // Delete material
    $material_id = $_GET['id'];
    
    // First delete from product associations
    $conn->query("DELETE FROM product_materials WHERE material_id = $material_id");
    
    // Then delete the material
    if($conn->query("DELETE FROM materials WHERE id = $material_id")) {
        header("Location: materials.php?success=Material deleted successfully");
    } else {
        header("Location: materials.php?error=Error deleting material");
    }
} else {
    header("Location: materials.php");
}
?>