<?php
require_once 'config.php';

if(isset($_GET['product_id'])) {
    $product_id = $_GET['product_id'];
    $result = $conn->query("SELECT * FROM product_materials WHERE product_id = $product_id");
    $materials = [];
    while($row = $result->fetch_assoc()) {
        $materials[] = $row;
    }
    echo json_encode($materials);
}
?>