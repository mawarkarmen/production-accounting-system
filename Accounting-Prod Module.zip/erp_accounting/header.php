<header>
    <div class="logo">
        <img src="assets/images/logo.jpg" alt="ERP Production Logo">
        <h1>PT. Sumber Rejeki</h1>
    </div>
    <div class="user-profile">
        <span>Admin</span>
        <img src="assets/images/user-avatar.jpg" alt="User Profile">
    </div>
</header>
<nav>
    <ul>
        <li><a href="index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : '' ?>">Dashboard</a></li>
        <li><a href="products.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'products.php' ? 'active' : '' ?>">Products & Inventory</a></li>
        <li><a href="materials.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'materials.php' ? 'active' : '' ?>">Materials & Costs</a></li>
        <li><a href="costing.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'costing.php' ? 'active' : '' ?>">Production Costing</a></li>
        <li><a href="overhead.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'overhead.php' ? 'active' : '' ?>">Overhead Allocation</a></li>
        <li><a href="reports.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'active' : '' ?>">Reports</a></li>
    </ul>
</nav>