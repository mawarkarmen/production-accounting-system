<?php
require_once 'config.php';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    
    if($action == 'add') {
        // Insert new product
        $stmt = $conn->prepare("INSERT INTO products (name, description) VALUES (?, ?)");
        $stmt->bind_param("ss", $name, $description);
        
        if($stmt->execute()) {
            $product_id = $conn->insert_id;
            
            // Process material requirements
            if(isset($_POST['materials'])) {
                foreach($_POST['materials'] as $material_id => $quantity) {
                    if($quantity > 0) {
                        $stmt = $conn->prepare("INSERT INTO product_materials (product_id, material_id, quantity) VALUES (?, ?, ?)");
                        $stmt->bind_param("iid", $product_id, $material_id, $quantity);
                        $stmt->execute();
                    }
                }
            }
            
            header("Location: products.php?success=Product added successfully");
        } else {
            header("Location: products.php?error=Error adding product");
        }
    } elseif($action == 'edit') {
        // Update existing product
        $product_id = $_POST['product_id'];
        $stmt = $conn->prepare("UPDATE products SET name = ?, description = ? WHERE id = ?");
        $stmt->bind_param("ssi", $name, $description, $product_id);
        
        if($stmt->execute()) {
            // First delete existing material requirements
            $conn->query("DELETE FROM product_materials WHERE product_id = $product_id");
            
            // Then add the updated material requirements
            if(isset($_POST['materials'])) {
                foreach($_POST['materials'] as $material_id => $quantity) {
                    if($quantity > 0) {
                        $stmt = $conn->prepare("INSERT INTO product_materials (product_id, material_id, quantity) VALUES (?, ?, ?)");
                        $stmt->bind_param("iid", $product_id, $material_id, $quantity);
                        $stmt->execute();
                    }
                }
            }
            
            header("Location: products.php?success=Product updated successfully");
        } else {
            header("Location: products.php?error=Error updating product");
        }
    }
} elseif(isset($_GET['delete'])) {
    // Delete product
    $product_id = $_GET['id'];
    
    // First delete associated materials
    $conn->query("DELETE FROM product_materials WHERE product_id = $product_id");
    
    // Then delete the product
    if($conn->query("DELETE FROM products WHERE id = $product_id")) {
        header("Location: products.php?success=Product deleted successfully");
    } else {
        header("Location: products.php?error=Error deleting product");
    }
} else {
    header("Location: products.php");
}
?>