<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Production ERP System</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <?php include 'header.php'; ?>
        
        <main>
            <div class="page-header">
                <h2><i class="fas fa-tachometer-alt"></i> Dashboard</h2>
                <div class="breadcrumb">
                    <span>Home</span> / <span class="active">Dashboard</span>
                </div>
            </div>
            
            <!-- Alert Notification -->
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> The system is running well. Last updated: <?php echo date('d M Y H:i:s'); ?>
            </div>
            
            <!-- Dashboard Cards -->
            <div class="dashboard-cards">
                <div class="card">
                    <h3><i class="fas fa-box"></i> Total Products</h3>
                    <?php
                    $query = "SELECT COUNT(*) as total FROM products";
                    $result = $conn->query($query);
                    $row = $result->fetch_assoc();
                    echo "<p>" . $row['total'] . "</p>";
                    ?>
                    <a href="products.php" class="btn btn-sm">View Details</a>
                </div>
                
                <div class="card">
                    <h3><i class="fas fa-cubes"></i> Raw Material Stock</h3>
                    <?php
                    $query = "SELECT SUM(quantity) as total FROM materials WHERE type = 'raw'";
                    $result = $conn->query($query);
                    $row = $result->fetch_assoc();
                    echo "<p>" . $row['total'] . " units</p>";
                    ?>
                    <a href="products.php?tab=raw-materials" class="btn btn-sm">View Details</a>
                </div>
                
                <div class="card">
                    <h3><i class="fas fa-tshirt"></i> Finished Goods Stock</h3>
                    <?php
                    $query = "SELECT SUM(quantity) as total FROM materials WHERE type = 'finished'";
                    $result = $conn->query($query);
                    $row = $result->fetch_assoc();
                    echo "<p>" . $row['total'] . " units</p>";
                    ?>
                    <a href="products.php?tab=finished-goods" class="btn btn-sm">View Details</a>
                </div>
                
                <div class="card">
                    <h3><i class="fas fa-dollar-sign"></i> Total Inventory Value</h3>
                    <?php
                    $query = "SELECT SUM(quantity * unit_price) as total FROM materials";
                    $result = $conn->query($query);
                    $row = $result->fetch_assoc();
                    echo "<p>Rp " . number_format($row['total'], 2) . "</p>";
                    ?>
                    <a href="reports.php" class="btn btn-sm">View Report</a>
                </div>
            </div>
            
            <!-- Recent Activity -->
            <div class="card">
                <h3><i class="fas fa-history"></i> Recent Activity</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Time</th>
                            <th>Activity</th>
                            <th>User</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo date('d M H:i'); ?></td>
                            <td>System Login</td>
                            <td>Admin</td>
                            <td><button class="btn btn-sm">Details</button></td>
                        </tr>
                        <!-- Add more activity rows from database -->
                    </tbody>
                </table>
            </div>
            
            <!-- Quick Actions -->
            <div class="card">
                <h3><i class="fas fa-bolt"></i> Quick Actions</h3>
                <div class="quick-actions">
                    <a href="products.php?action=add" class="btn"><i class="fas fa-plus"></i> Add Product</a>
                    <a href="materials.php?action=add" class="btn"><i class="fas fa-plus"></i> Add Material</a>
                    <a href="costing.php" class="btn"><i class="fas fa-calculator"></i> Calculate Cost</a>
                    <a href="reports.php" class="btn"><i class="fas fa-file-alt"></i> Generate Report</a>
                </div>
            </div>
        </main>
        
    </div>
    
    <script src="assets/js/script.js"></script>
    <!-- Include DataTables if needed -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
</body>
</html>
