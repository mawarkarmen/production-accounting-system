<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Production ERP System</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <?php include 'header.php'; ?>
        
        <main>
            <div class="page-header">
                <h2><i class="fas fa-file-alt"></i> Reports</h2>
                <div class="breadcrumb">
                    <span>Home</span> / <span class="active">Reports</span>
                </div>
            </div>
            
            <?php
            // Check if we're viewing a specific production run report
            $production_run_id = isset($_GET['production_run_id']) ? intval($_GET['production_run_id']) : 0;
            
            if($production_run_id > 0):
                // Get production run details
                $query = "SELECT pr.*, p.name as product_name 
                          FROM production_runs pr
                          JOIN products p ON pr.product_id = p.id
                          WHERE pr.id = $production_run_id";
                $result = $conn->query($query);
                $production_run = $result->fetch_assoc();
                
                // Get materials used in this production run
                $query = "SELECT m.*, pm.quantity as required_quantity 
                          FROM product_materials pm
                          JOIN materials m ON pm.material_id = m.id
                          WHERE pm.product_id = {$production_run['product_id']}";
                $result = $conn->query($query);
                $materials = [];
                while($row = $result->fetch_assoc()) {
                    $materials[] = $row;
                }
                
                // Get labor costs
                $query = "SELECT * FROM labor_costs";
                $result = $conn->query($query);
                $labor_costs = [];
                while($row = $result->fetch_assoc()) {
                    $labor_costs[] = $row;
                }
            ?>
            <div class="card">
                <h3>Production Cost Report</h3>
                <div class="report-header">
                    <h4>PT. Sumber Rejeki</h4>
                    <p>Production Cost Report for <?php echo $production_run['product_name']; ?></p>
                    <p>Production Date: <?php echo date('d M Y', strtotime($production_run['created_at'])); ?></p>
                </div>
                
                <div class="report-section">
                    <h4>Production Details</h4>
                    <table>
                        <tr>
                            <th>Product Name:</th>
                            <td><?php echo $production_run['product_name']; ?></td>
                        </tr>
                        <tr>
                            <th>Production Quantity:</th>
                            <td><?php echo $production_run['quantity']; ?> units</td>
                        </tr>
                        <tr>
                            <th>Total Production Cost:</th>
                            <td>Rp <?php echo number_format($production_run['total_cost'], 2); ?></td>
                        </tr>
                        <tr>
                            <th>Cost per Unit:</th>
                            <td>Rp <?php echo number_format($production_run['cost_per_unit'], 2); ?></td>
                        </tr>
                        <tr>
                            <th>Selling Price (50% markup):</th>
                            <td>Rp <?php echo number_format($production_run['selling_price'], 2); ?></td>
                        </tr>
                    </table>
                </div>
                
                <div class="report-section">
                    <h4>Material Costs</h4>
                    <table>
                        <thead>
                            <tr>
                                <th>Material</th>
                                <th>Category</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Total Cost</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $total_direct_materials = 0;
                            $total_indirect_materials = 0;
                            
                            foreach($materials as $material):
                                $total_cost = $material['required_quantity'] * $material['unit_price'];
                                
                                if($material['category'] == 'direct') {
                                    $total_direct_materials += $total_cost;
                                } else {
                                    $total_indirect_materials += $total_cost;
                                }
                            ?>
                            <tr>
                                <td><?php echo $material['name']; ?></td>
                                <td><?php echo ucfirst($material['category']); ?></td>
                                <td><?php echo $material['required_quantity'] . ' ' . $material['unit']; ?></td>
                                <td>Rp <?php echo number_format($material['unit_price'], 2); ?></td>
                                <td>Rp <?php echo number_format($total_cost, 2); ?></td>
                            </tr>
                            <?php endforeach; ?>
                            <tr class="total-row">
                                <td colspan="4" class="text-right"><strong>Total Direct Materials:</strong></td>
                                <td><strong>Rp <?php echo number_format($total_direct_materials, 2); ?></strong></td>
                            </tr>
                            <tr class="total-row">
                                <td colspan="4" class="text-right"><strong>Total Indirect Materials:</strong></td>
                                <td><strong>Rp <?php echo number_format($total_indirect_materials, 2); ?></strong></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <div class="report-section">
                    <h4>Labor Costs</h4>
                    <table>
                        <thead>
                            <tr>
                                <th>Labor</th>
                                <th>Category</th>
                                <th>Hourly Rate</th>
                                <th>Hours per Unit</th>
                                <th>Cost per Unit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $total_direct_labor = 0;
                            $total_indirect_labor = 0;
                            
                            foreach($labor_costs as $labor):
                                $cost_per_unit = $labor['hourly_rate'] * $labor['hours_per_unit'];
                                
                                if($labor['category'] == 'direct') {
                                    $total_direct_labor += $cost_per_unit;
                                } else {
                                    $total_indirect_labor += $cost_per_unit;
                                }
                            ?>
                            <tr>
                                <td><?php echo $labor['name']; ?></td>
                                <td><?php echo ucfirst($labor['category']); ?></td>
                                <td>Rp <?php echo number_format($labor['hourly_rate'], 2); ?></td>
                                <td><?php echo $labor['hours_per_unit']; ?></td>
                                <td>Rp <?php echo number_format($cost_per_unit, 2); ?></td>
                            </tr>
                            <?php endforeach; ?>
                            <tr class="total-row">
                                <td colspan="4" class="text-right"><strong>Total Direct Labor:</strong></td>
                                <td><strong>Rp <?php echo number_format($total_direct_labor, 2); ?></strong></td>
                            </tr>
                            <tr class="total-row">
                                <td colspan="4" class="text-right"><strong>Total Indirect Labor:</strong></td>
                                <td><strong>Rp <?php echo number_format($total_indirect_labor, 2); ?></strong></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <div class="report-section">
                    <h4>Overhead Allocation</h4>
                    <table>
                        <thead>
                            <tr>
                                <th>Overhead Cost</th>
                                <th>Allocation Base</th>
                                <th>Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT oa.*, oc.name as overhead_name 
                                      FROM overhead_allocations oa
                                      JOIN overhead_costs oc ON oa.overhead_id = oc.id
                                      WHERE oa.product_id = {$production_run['product_id']}";
                            $result = $conn->query($query);
                            
                            $total_overhead = 0;
                            if($result && $result->num_rows > 0) {
                                while($row = $result->fetch_assoc()):
                                    $total_overhead += $row['amount'];
                            ?>
                            <tr>
                                <td><?php echo $row['overhead_name']; ?></td>
                                <td><?php echo $row['allocation_base']; ?></td>
                                <td>Rp <?php echo number_format($row['amount'], 2); ?></td>
                            </tr>
                            <?php 
                                endwhile;
                            } else {
                                echo "<tr><td colspan='3'>No overhead allocations found</td></tr>";
                            }
                            ?>
                            <tr class="total-row">
                                <td colspan="2" class="text-right"><strong>Total Overhead:</strong></td>
                                <td><strong>Rp <?php echo number_format($total_overhead, 2); ?></strong></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <div class="text-right mt-3">
                    <button onclick="window.print()" class="btn"><i class="fas fa-print"></i> Print Report</button>
                </div>
            </div>
            <?php else: ?>
            <div class="card">
                <h3>Available Reports</h3>
                <div class="quick-actions">
                    <a href="reports.php?type=inventory" class="btn"><i class="fas fa-boxes"></i> Inventory Report</a>
                    <a href="reports.php?type=production" class="btn"><i class="fas fa-industry"></i> Production Report</a>
                    <a href="reports.php?type=costing" class="btn"><i class="fas fa-calculator"></i> Costing Report</a>
                    <a href="reports.php?type=overhead" class="btn"><i class="fas fa-random"></i> Overhead Allocation Report</a>
                </div>
            </div>
            
            <?php
            $report_type = isset($_GET['type']) ? $_GET['type'] : '';
            
            if($report_type == 'inventory'):
            ?>
            <div class="card">
                <h3>Inventory Report</h3>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Material/Product</th>
                                <th>Type</th>
                                <th>Category</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Total Value</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Raw materials
                            $query = "SELECT * FROM materials WHERE type = 'raw'";
                            $result = $conn->query($query);
                            while($row = $result->fetch_assoc()):
                            ?>
                            <tr>
                                <td><?php echo $row['name']; ?></td>
                                <td>Raw Material</td>
                                <td><?php echo ucfirst($row['category']); ?></td>
                                <td><?php echo $row['quantity'] . ' ' . $row['unit']; ?></td>
                                <td>Rp <?php echo number_format($row['unit_price'], 2); ?></td>
                                <td>Rp <?php echo number_format($row['quantity'] * $row['unit_price'], 2); ?></td>
                            </tr>
                            <?php endwhile; ?>
                            
                            <!-- Finished goods -->
                            <?php
                            $query = "SELECT p.id, p.name, 
                                     IFNULL(SUM(pr.quantity), 0) as quantity,
                                     IFNULL(AVG(pr.cost_per_unit), 0) as unit_cost
                                     FROM products p
                                     LEFT JOIN production_runs pr ON p.id = pr.product_id
                                     GROUP BY p.id";
                            $result = $conn->query($query);
                            while($row = $result->fetch_assoc()):
                            ?>
                            <tr>
                                <td><?php echo $row['name']; ?></td>
                                <td>Finished Good</td>
                                <td>Product</td>
                                <td><?php echo $row['quantity']; ?> units</td>
                                <td>Rp <?php echo number_format($row['unit_cost'], 2); ?></td>
                                <td>Rp <?php echo number_format($row['quantity'] * $row['unit_cost'], 2); ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php elseif($report_type == 'production'): ?>
            <div class="card">
                <h3>Production Report</h3>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Product</th>
                                <th>Quantity</th>
                                <th>Total Cost</th>
                                <th>Cost per Unit</th>
                                <th>Selling Price</th>
                                <th>Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT pr.*, p.name as product_name 
                                      FROM production_runs pr
                                      JOIN products p ON pr.product_id = p.id
                                      ORDER BY pr.created_at DESC";
                            $result = $conn->query($query);
                            
                            while($row = $result->fetch_assoc()):
                            ?>
                            <tr>
                                <td><?php echo date('d M Y', strtotime($row['created_at'])); ?></td>
                                <td><?php echo $row['product_name']; ?></td>
                                <td><?php echo $row['quantity']; ?></td>
                                <td>Rp <?php echo number_format($row['total_cost'], 2); ?></td>
                                <td>Rp <?php echo number_format($row['cost_per_unit'], 2); ?></td>
                                <td>Rp <?php echo number_format($row['selling_price'], 2); ?></td>
                                <td><a href="reports.php?production_run_id=<?php echo $row['id']; ?>" class="btn btn-sm">View</a></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php elseif($report_type == 'costing'): ?>
            <div class="card">
                <h3>Costing Report</h3>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Direct Materials</th>
                                <th>Direct Labor</th>
                                <th>Indirect Materials</th>
                                <th>Indirect Labor</th>
                                <th>Overhead</th>
                                <th>Total Cost</th>
                                <th>Cost per Unit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT p.id, p.name, 
                                     IFNULL(AVG(pr.cost_per_unit), 0) as avg_cost_per_unit
                                     FROM products p
                                     LEFT JOIN production_runs pr ON p.id = pr.product_id
                                     GROUP BY p.id";
                            $result = $conn->query($query);
                            
                            while($product = $result->fetch_assoc()):
                                // Get materials for this product
                                $materials_query = "SELECT m.*, pm.quantity as required_quantity 
                                                  FROM product_materials pm
                                                  JOIN materials m ON pm.material_id = m.id
                                                  WHERE pm.product_id = {$product['id']}";
                                $materials_result = $conn->query($materials_query);
                                
                                $direct_materials = 0;
                                $indirect_materials = 0;
                                while($material = $materials_result->fetch_assoc()) {
                                    $total = $material['required_quantity'] * $material['unit_price'];
                                    if($material['category'] == 'direct') {
                                        $direct_materials += $total;
                                    } else {
                                        $indirect_materials += $total;
                                    }
                                }
                                
                                // Get labor costs
                                $labor_query = "SELECT * FROM labor_costs";
                                $labor_result = $conn->query($labor_query);
                                
                                $direct_labor = 0;
                                $indirect_labor = 0;
                                while($labor = $labor_result->fetch_assoc()) {
                                    $total = $labor['hourly_rate'] * $labor['hours_per_unit'];
                                    if($labor['category'] == 'direct') {
                                        $direct_labor += $total;
                                    } else {
                                        $indirect_labor += $total;
                                    }
                                }
                                
                                // Get overhead
                                $overhead_query = "SELECT SUM(amount) as total_overhead 
                                                  FROM overhead_allocations 
                                                  WHERE product_id = {$product['id']}";
                                $overhead_result = $conn->query($overhead_query);
                                $overhead = $overhead_result->fetch_assoc()['total_overhead'] ?? 0;
                                
                                $total_cost = $direct_materials + $direct_labor + $indirect_materials + $indirect_labor + $overhead;
                            ?>
                            <tr>
                                <td><?php echo $product['name']; ?></td>
                                <td>Rp <?php echo number_format($direct_materials, 2); ?></td>
                                <td>Rp <?php echo number_format($direct_labor, 2); ?></td>
                                <td>Rp <?php echo number_format($indirect_materials, 2); ?></td>
                                <td>Rp <?php echo number_format($indirect_labor, 2); ?></td>
                                <td>Rp <?php echo number_format($overhead, 2); ?></td>
                                <td>Rp <?php echo number_format($total_cost, 2); ?></td>
                                <td>Rp <?php echo number_format($product['avg_cost_per_unit'], 2); ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php elseif($report_type == 'overhead'): ?>
            <div class="card">
                <h3>Overhead Allocation Report</h3>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Overhead Cost</th>
                                <th>Product</th>
                                <th>Allocation Base</th>
                                <th>Allocation %</th>
                                <th>Amount</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT oa.*, oc.name as overhead_name, p.name as product_name 
                                      FROM overhead_allocations oa
                                      JOIN overhead_costs oc ON oa.overhead_id = oc.id
                                      JOIN products p ON oa.product_id = p.id
                                      ORDER BY oa.created_at DESC";
                            $result = $conn->query($query);
                            
                            if($result && $result->num_rows > 0) {
                                while($row = $result->fetch_assoc()):
                            ?>
                            <tr>
                                <td><?php echo $row['overhead_name']; ?></td>
                                <td><?php echo $row['product_name']; ?></td>
                                <td><?php echo $row['allocation_base']; ?></td>
                                <td><?php echo $row['allocation_percentage']; ?>%</td>
                                <td>Rp <?php echo number_format($row['amount'], 2); ?></td>
                                <td><?php echo date('d M Y', strtotime($row['created_at'])); ?></td>
                            </tr>
                            <?php 
                                endwhile;
                            } else {
                                echo "<tr><td colspan='6'>No overhead allocations found</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </main>
    </div>
    
    <script src="assets/js/script.js"></script>
</body>
</html>