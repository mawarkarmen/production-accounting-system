<?php
require_once 'config.php';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];
    $name = $conn->real_escape_string($_POST['name']);
    $category = $_POST['category'];
    $hourly_rate = floatval($_POST['hourly_rate']);
    $hours_per_unit = floatval($_POST['hours_per_unit']);
    
    if($action == 'add') {
        $stmt = $conn->prepare("INSERT INTO labor_costs (name, category, hourly_rate, hours_per_unit) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssdd", $name, $category, $hourly_rate, $hours_per_unit);
        
        if($stmt->execute()) {
            header("Location: materials.php?tab=labor&success=Labor cost added successfully");
        } else {
            header("Location: materials.php?tab=labor&error=Error adding labor cost");
        }
    } elseif($action == 'edit') {
        $labor_id = intval($_POST['labor_id']);
        $stmt = $conn->prepare("UPDATE labor_costs SET name = ?, category = ?, hourly_rate = ?, hours_per_unit = ? WHERE id = ?");
        $stmt->bind_param("ssddi", $name, $category, $hourly_rate, $hours_per_unit, $labor_id);
        
        if($stmt->execute()) {
            header("Location: materials.php?tab=labor&success=Labor cost updated successfully");
        } else {
            header("Location: materials.php?tab=labor&error=Error updating labor cost");
        }
    }
} elseif(isset($_GET['delete'])) {
    $labor_id = intval($_GET['id']);
    
    if($conn->query("DELETE FROM labor_costs WHERE id = $labor_id")) {
        header("Location: materials.php?tab=labor&success=Labor cost deleted successfully");
    } else {
        header("Location: materials.php?tab=labor&error=Error deleting labor cost");
    }
} else {
    header("Location: materials.php?tab=labor");
}
?>